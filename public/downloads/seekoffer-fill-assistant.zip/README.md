# 寻鹿填报助手 Chrome / Edge 插件

这是寻鹿 Seekoffer 的 Manifest V3 浏览器插件。用户先在寻鹿申请清单中准备并确认字段，再切换到学校报名页，通过插件弹窗逐项选择、检查和填入。

## v1.0 安全边界

- 报名网站使用 `activeTab`：只有用户在当前标签页点击插件图标后，插件才获得临时注入权限。
- 固定 host permission 覆盖 `seekoffer.com.cn`、`www.seekoffer.com.cn` 与寻鹿自己的 Supabase Edge Function。前两者用于接收用户主动发送的字段；后者仅兑换一次性填报授权，不上传姓名、手机号、邮箱或字段值。
- 字段在扩展会话存储中保留 30 分钟，过期后自动清除；URL 查询参数和片段不会写入缓存。
- `alarms` 只用于在 30 分钟到期时执行本地清理，不弹提醒，也不产生网络请求。
- 密码、验证码、文件上传、登录账号、搜索框、复选框、单选框和提交按钮不会进入扫描结果。
- 默认只选择高置信且为空的页面字段；页面已有内容受到保护，开启“允许覆盖”后仍需逐项勾选。
- 相近候选会标记为“有歧义”并停止自动填写；下拉选项只有唯一匹配时才会写入。
- 插件从不点击“保存”“下一步”或“提交”，最终核对和提交始终由用户完成。
- 网页发送字段前先取得 5 分钟有效的一次性授权；插件向计费接口兑换成功后才暂存字段。授权接口只收到随机令牌，不收到字段内容。

## 本地安装

1. 在仓库执行 `npm run extension:package`，生成 `public/downloads/seekoffer-fill-assistant.zip`。
2. 解压 zip。
3. Chrome 打开 `chrome://extensions`；Edge 打开 `edge://extensions`。
4. 开启“开发者模式”，点击“加载已解压的扩展程序”，选择解压目录。
5. 返回寻鹿 `/me`，点击“检测插件”，核对字段并发送。
6. 切换到报名页，点击插件图标，逐项选择后填入；最后人工核对并提交。

## 适配器注册表

适配器位于 `src/adapters.js`，当前按域名与页面结构选择：

- `university-portal`：高校 `edu.cn`、招生/申请/研究生报名类域名，支持 Element、Ant Design、Layui 等常见表单容器及中英文字段名。
- `online-form`：腾讯问卷、金数据、问卷网、Microsoft Forms、Formstack 等在线表单题目结构。
- `generic-form`：其他标准 HTML 表单的保守兜底策略。

字段匹配先计算所有“语义字段 × 页面控件”的得分，再按最高分全局分配，避免 `applyMajor` 被“本科专业”提前占用。若同一语义字段存在得分接近的多个候选，会返回 `ambiguous`，由用户手动处理。

## 通信协议 v3

- `SEEK_OFFER_FILL_ASSISTANT_PING`：寻鹿检测插件连接。
- `SEEK_OFFER_FILL_ASSISTANT_READY`：插件返回版本与能力声明。
- `SEEK_OFFER_FILL_FIELDS`：寻鹿发送本次用户确认的字段和一次性短效授权。
- `SEEK_OFFER_FILL_FIELDS_STORED`：插件确认字段已安全暂存并返回过期时间。

每次请求携带 `requestId`，网页只处理对应请求的结果。后台还会校验消息来源、字段白名单、字段数量、值长度和一次性授权；只有插件实际兑换授权时才消耗一次免费额度。

## 开发检查

- `npm run extension:icons`：从品牌 Logo 生成 16/32/48/128 四种扩展图标。
- `npm run extension:check`：检查 Manifest、权限白名单、注入域名、必要文件、内联脚本和动态代码执行。
- `npm test -- --run tests/fill-assistant-extension.test.ts`：运行字段冲突、歧义、敏感字段和缓存安全测试。
- `npm run extension:package`：生成可下载 zip。
