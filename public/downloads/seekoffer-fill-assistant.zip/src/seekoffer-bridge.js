(() => {
  if (window.__seekOfferFillSeekofferBridgeLoaded) return;
  window.__seekOfferFillSeekofferBridgeLoaded = true;

  const protocolVersion = 3;
  const extensionSource = 'seekoffer-extension';
  const webSource = 'seekoffer-web';
  const readyEvent = 'SEEK_OFFER_FILL_ASSISTANT_READY';
  const pingEvent = 'SEEK_OFFER_FILL_ASSISTANT_PING';
  const fillEvent = 'SEEK_OFFER_FILL_FIELDS';
  const storedEvent = 'SEEK_OFFER_FILL_FIELDS_STORED';

  function sendToSeekoffer(type, payload = {}) {
    window.postMessage(
      {
        source: extensionSource,
        type,
        version: protocolVersion,
        extensionVersion: chrome.runtime.getManifest().version,
        ...payload
      },
      window.location.origin
    );
  }

  function announceReady(requestId = '') {
    sendToSeekoffer(readyEvent, {
      requestId,
      capabilities: [
        'active-tab-scan',
        'adapter-registry-v2',
        'field-selection',
        'non-destructive-fill',
        'payload-expiry',
        'server-authorized-fill'
      ]
    });
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const data = event.data;
    if (!data || data.source !== webSource || typeof data.type !== 'string') return;

    if (data.type === pingEvent) {
      announceReady(typeof data.requestId === 'string' ? data.requestId : '');
      return;
    }

    if (data.type !== fillEvent || !Array.isArray(data.fields)) return;

    const requestId = typeof data.requestId === 'string' ? data.requestId : '';
    chrome.runtime
      .sendMessage({
        type: 'STORE_FILL_PAYLOAD',
        payload: {
          applicationId: data.applicationId,
          authorization: data.authorization,
          fields: data.fields,
          sourceUrl: window.location.href
        }
      })
      .then((result) => sendToSeekoffer(storedEvent, { requestId, ...(result || {}) }))
      .catch(() => sendToSeekoffer(storedEvent, { requestId, ok: false, error: 'store_failed' }));
  });

  announceReady();
})();
