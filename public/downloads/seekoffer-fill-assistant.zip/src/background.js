const PROTOCOL_VERSION = 3;
const FILL_PAYLOAD_KEY = 'seekoffer-fill-payload-v2';
const PAYLOAD_EXPIRY_ALARM = 'seekoffer-fill-payload-expiry';
const PAYLOAD_TTL_MS = 30 * 60 * 1000;
const TRUSTED_SEEKOFFER_HOSTS = new Set(['seekoffer.com.cn', 'www.seekoffer.com.cn']);
const TRUSTED_BILLING_ORIGIN = 'https://mnotoltpythkayguhnrk.supabase.co';
const TRUSTED_BILLING_PATH = '/functions/v1/billing-api';
const ALLOWED_FIELD_IDS = new Set([
  'name',
  'email',
  'phone',
  'undergraduateSchool',
  'major',
  'grade',
  'targetMajor',
  'targetRegion',
  'targetSchool',
  'targetDepartment'
]);

function getStorageArea() {
  return chrome.storage.session;
}

function parseUrl(value) {
  try {
    return new URL(String(value || ''));
  } catch {
    return null;
  }
}

function isTrustedSeekofferSender(sender) {
  const url = parseUrl(sender?.url || sender?.tab?.url);
  return Boolean(url && url.protocol === 'https:' && TRUSTED_SEEKOFFER_HOSTS.has(url.hostname));
}

function sanitizeSourceUrl(value) {
  const url = parseUrl(value);
  if (!url || url.protocol !== 'https:' || !TRUSTED_SEEKOFFER_HOSTS.has(url.hostname)) return '';
  return `${url.origin}${url.pathname}`.slice(0, 500);
}

function normalizeFields(fields) {
  if (!Array.isArray(fields)) return [];

  const uniqueFields = new Map();
  for (const field of fields.slice(0, 30)) {
    if (!field || typeof field.id !== 'string' || typeof field.value !== 'string') continue;
    const id = field.id.slice(0, 80);
    const value = field.value.trim().slice(0, 500);
    if (!ALLOWED_FIELD_IDS.has(id) || !value || uniqueFields.has(id)) continue;
    uniqueFields.set(id, {
      id,
      label: typeof field.label === 'string' ? field.label.slice(0, 120) : id,
      value,
      source: typeof field.source === 'string' ? field.source.slice(0, 160) : ''
    });
  }
  return [...uniqueFields.values()];
}

function payloadIsExpired(payload, now = Date.now()) {
  const expiresAt = Date.parse(String(payload?.expiresAt || ''));
  return !Number.isFinite(expiresAt) || expiresAt <= now;
}

async function consumeFillAuthorization(authorization) {
  const token = typeof authorization?.token === 'string' ? authorization.token.trim() : '';
  const verificationUrl = parseUrl(authorization?.verificationUrl);
  const expiresAt = Date.parse(String(authorization?.expiresAt || ''));
  if (
    !/^[A-Za-z0-9_-]{40,64}$/.test(token) ||
    !verificationUrl ||
    verificationUrl.origin !== TRUSTED_BILLING_ORIGIN ||
    verificationUrl.pathname !== TRUSTED_BILLING_PATH ||
    verificationUrl.search ||
    !Number.isFinite(expiresAt)
  ) {
    return { ok: false, error: 'invalid_fill_session' };
  }
  if (expiresAt <= Date.now()) {
    return { ok: false, error: 'fill_session_expired' };
  }

  try {
    const response = await fetch(verificationUrl.toString(), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'consume-fill-session', token })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result.allowed) {
      return { ok: false, error: String(result.error || 'fill_authorization_failed') };
    }
    return { ok: true, fillUsage: result.fillUsage || null };
  } catch {
    return { ok: false, error: 'fill_authorization_unavailable' };
  }
}

async function storeFillPayload(message, sender) {
  if (!isTrustedSeekofferSender(sender)) {
    return { ok: false, error: 'untrusted_source' };
  }

  const fields = normalizeFields(message.fields);
  if (!fields.length) {
    return { ok: false, error: 'empty_fields' };
  }

  const authorization = await consumeFillAuthorization(message.authorization);
  if (!authorization.ok) {
    return authorization;
  }

  const now = Date.now();
  const payload = {
    protocolVersion: PROTOCOL_VERSION,
    applicationId: typeof message.applicationId === 'string' ? message.applicationId.slice(0, 120) : '',
    fields,
    sourceUrl: sanitizeSourceUrl(message.sourceUrl || sender?.url || sender?.tab?.url),
    updatedAt: new Date(now).toISOString(),
    expiresAt: new Date(now + PAYLOAD_TTL_MS).toISOString(),
    sourceTabId: sender?.tab?.id ?? null
  };

  await getStorageArea().set({ [FILL_PAYLOAD_KEY]: payload });
  await chrome.alarms.clear(PAYLOAD_EXPIRY_ALARM);
  chrome.alarms.create(PAYLOAD_EXPIRY_ALARM, { when: now + PAYLOAD_TTL_MS });
  return {
    ok: true,
    protocolVersion: PROTOCOL_VERSION,
    fieldCount: payload.fields.length,
    updatedAt: payload.updatedAt,
    expiresAt: payload.expiresAt,
    fillUsage: authorization.fillUsage
  };
}

async function getFillPayload() {
  const result = await getStorageArea().get(FILL_PAYLOAD_KEY);
  const payload = result[FILL_PAYLOAD_KEY] || null;
  if (!payload) return { ok: true, payload: null };
  if (payloadIsExpired(payload)) {
    await getStorageArea().remove(FILL_PAYLOAD_KEY);
    await chrome.alarms.clear(PAYLOAD_EXPIRY_ALARM);
    return { ok: true, payload: null, expired: true };
  }
  return { ok: true, payload };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'STORE_FILL_PAYLOAD') {
    storeFillPayload(message.payload || message, sender)
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, error: 'store_failed' }));
    return true;
  }

  if (message?.type === 'GET_FILL_PAYLOAD') {
    getFillPayload()
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, error: 'read_failed' }));
    return true;
  }

  if (message?.type === 'CLEAR_FILL_PAYLOAD') {
    Promise.all([
      getStorageArea().remove(FILL_PAYLOAD_KEY),
      chrome.alarms.clear(PAYLOAD_EXPIRY_ALARM)
    ])
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false, error: 'clear_failed' }));
    return true;
  }

  return false;
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== PAYLOAD_EXPIRY_ALARM) return;
  void getStorageArea().remove(FILL_PAYLOAD_KEY);
});

globalThis.SeekOfferFillBackground = {
  ALLOWED_FIELD_IDS,
  PAYLOAD_TTL_MS,
  isTrustedSeekofferSender,
  normalizeFields,
  payloadIsExpired,
  sanitizeSourceUrl,
  consumeFillAuthorization,
  storeFillPayload
};
