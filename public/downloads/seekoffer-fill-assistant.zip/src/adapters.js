(() => {
  const MATCH_THRESHOLD = 68;
  const AMBIGUITY_GAP = 8;
  const blockedAutocompleteValues = new Set([
    'username',
    'current-password',
    'new-password',
    'one-time-code',
    'cc-number',
    'cc-csc'
  ]);

  const fieldDefinitions = {
    name: {
      label: '真实姓名',
      aliases: ['真实姓名', '姓名', '申请人姓名', '考生姓名', '报名人姓名', '学生姓名', 'full name', 'real name', 'student name'],
      blocked: ['用户名', '登录名', '账号', '昵称', '紧急联系人', '家长', '导师', '推荐人', '验证码']
    },
    email: {
      label: '邮箱',
      aliases: ['邮箱', '电子邮箱', '联系邮箱', '个人邮箱', '电子邮件', 'email', 'e-mail'],
      blocked: ['验证码', '导师', '推荐人', '紧急联系人', '家长']
    },
    phone: {
      label: '手机号',
      aliases: ['手机号', '手机号码', '联系电话', '个人手机', '移动电话', 'mobile', 'phone', 'telephone'],
      blocked: ['验证码', '紧急联系人', '家长', '父亲', '母亲', '导师', '座机']
    },
    undergraduateSchool: {
      label: '本科院校',
      aliases: ['本科院校', '本科就读院校', '本科毕业院校', '毕业院校', '就读学校', '本科学校', 'undergraduate school', 'graduation school'],
      blocked: ['高中', '研究生', '报考院校', '申请院校', '目标院校']
    },
    major: {
      label: '本科专业',
      aliases: ['本科专业', '所学专业', '本科所学专业', '当前专业', '本专业', 'undergraduate major', 'bachelor major', 'current major'],
      blocked: ['报考专业', '申请专业', '意向专业', '目标专业', '研究方向']
    },
    grade: {
      label: '当前年级',
      aliases: ['当前年级', '所在年级', '本科年级', '学生年级', 'grade', 'current grade'],
      blocked: ['入学年级', '招生年级', '录取年级', '报考年级']
    },
    targetMajor: {
      label: '申请方向',
      aliases: ['申请方向', '报考专业', '申请专业', '意向专业', '目标专业', '研究方向', 'target major', 'apply major', 'intended major'],
      blocked: ['本科专业', '所学专业', '当前专业', '毕业专业']
    },
    targetRegion: {
      label: '意向地区',
      aliases: ['意向地区', '报考地区', '申请地区', '目标地区', '意向城市', '目标城市', 'target region', 'preferred region'],
      blocked: ['生源地', '出生地', '籍贯', '现居地', '所在地区', '家庭住址', '详细地址']
    },
    targetSchool: {
      label: '申请院校',
      aliases: ['申请院校', '报考院校', '目标院校', '申请学校', '报考单位', 'target school', 'apply school'],
      blocked: ['本科院校', '毕业院校', '就读学校', '高中']
    },
    targetDepartment: {
      label: '申请院系',
      aliases: ['申请院系', '报考院系', '目标院系', '申请学院', '报考学院', '申请部门', 'target department', 'apply department'],
      blocked: ['本科院系', '所在院系', '毕业院系', '当前学院']
    }
  };

  function normalizeText(value) {
    return String(value || '')
      .replace(/\s+/g, ' ')
      .replace(/[：:()[\]（）【】_*\/\\|]/g, '')
      .trim()
      .toLowerCase();
  }

  function compactText(value) {
    return normalizeText(value).replace(/[\s\-_.]/g, '');
  }

  function unique(values) {
    return [...new Set(values.map((item) => normalizeText(item)).filter(Boolean))];
  }

  function textOf(node) {
    return node ? String(node.innerText || node.textContent || '') : '';
  }

  function labelTextOf(node) {
    if (!node?.cloneNode) return textOf(node);
    const clone = node.cloneNode(true);
    clone.querySelectorAll?.('input, textarea, select, button, option').forEach((control) => control.remove());
    return textOf(clone);
  }

  function safeQuery(selector, root = document) {
    try {
      return root.querySelector(selector);
    } catch {
      return null;
    }
  }

  function escapeCssValue(value) {
    if (globalThis.CSS?.escape) return globalThis.CSS.escape(value);
    return String(value).replace(/["\\]/g, '\\$&');
  }

  function elementLooksSensitive(element) {
    const identityParts = [
      element.getAttribute('id'),
      element.getAttribute('name'),
      element.getAttribute('autocomplete'),
      element.getAttribute('placeholder'),
      element.getAttribute('aria-label')
    ].map((value) => compactText(value)).filter(Boolean);
    const identity = identityParts.join(' ');
    if (identityParts.some((value) => /^(username|useraccount|login|loginname|account|accountname|用户名|登录名|登录账号|账号)$/i.test(value))) {
      return true;
    }
    if (/(captcha|verifycode|verificationcode|smscode|otp|password|token|search|keyword|query|验证码|校验码|搜索)/i.test(identity)) {
      return true;
    }

    const form = element.closest('form');
    if (!form || !form.querySelector('input[type="password"]')) return false;
    const formIdentity = compactText([
      form.getAttribute('id'),
      form.getAttribute('name'),
      form.getAttribute('class'),
      form.getAttribute('action'),
      form.getAttribute('aria-label')
    ].join(' '));
    return /(login|signin|signup|register|account|登录|注册|账号)/i.test(formIdentity);
  }

  function elementIsFillable(element) {
    if (!(element instanceof HTMLElement)) return false;
    if (element.matches('[disabled], [aria-disabled="true"], [readonly], [hidden]')) return false;
    if (element.offsetParent === null && element.getClientRects().length === 0) return false;
    if (elementLooksSensitive(element)) return false;

    const autocomplete = normalizeText(element.getAttribute('autocomplete'));
    if (blockedAutocompleteValues.has(autocomplete)) return false;
    if (element.tagName === 'SELECT' || element.tagName === 'TEXTAREA') return true;
    if (element.tagName !== 'INPUT') return false;

    const type = normalizeText(element.getAttribute('type') || 'text');
    return ![
      'hidden',
      'password',
      'file',
      'submit',
      'button',
      'reset',
      'checkbox',
      'radio',
      'image',
      'range',
      'color',
      'search'
    ].includes(type);
  }

  function nodeContainsFormControl(node) {
    return Boolean(node?.querySelector?.('input, textarea, select'));
  }

  function adjacentNodeLooksLikeLabel(node) {
    if (!node || nodeContainsFormControl(node)) return false;
    const labelText = normalizeText(textOf(node));
    if (!labelText || labelText.length > 120) return false;

    const tagName = String(node.tagName || '').toUpperCase();
    if (tagName === 'LABEL') return true;

    const identity = compactText([
      node.getAttribute?.('class'),
      node.getAttribute?.('data-label'),
      node.getAttribute?.('role')
    ].join(' '));
    if (/(label|fieldlabel|formlabel|caption|title)/i.test(identity)) return true;

    return ['SPAN', 'P', 'DIV', 'TH', 'TD', 'DT'].includes(tagName);
  }

  function getElementSignals(element, adapter) {
    const signals = [];
    const id = element.getAttribute('id');
    const name = element.getAttribute('name');
    const placeholder = element.getAttribute('placeholder');
    const ariaLabel = element.getAttribute('aria-label');
    const dataLabel = element.getAttribute('data-label') || element.getAttribute('data-field-label');
    const ariaLabelledBy = element.getAttribute('aria-labelledby');

    if (id) {
      const label = safeQuery(`label[for="${escapeCssValue(id)}"]`);
      if (label) signals.push(labelTextOf(label));
    }
    if (element.labels) {
      for (const label of element.labels) signals.push(labelTextOf(label));
    }
    if (placeholder) signals.push(placeholder);
    if (ariaLabel) signals.push(ariaLabel);
    if (dataLabel) signals.push(dataLabel);
    if (ariaLabelledBy) {
      for (const labelId of ariaLabelledBy.split(/\s+/).filter(Boolean)) {
        const labelledByNode = safeQuery(`#${escapeCssValue(labelId)}`);
        if (labelledByNode) signals.push(labelTextOf(labelledByNode));
      }
    }

    const closestLabel = element.closest('label');
    if (closestLabel) signals.push(labelTextOf(closestLabel));

    const parent = element.parentElement;
    const parentIsLabel = String(parent?.tagName || '').toUpperCase() === 'LABEL';
    if (parent && !parentIsLabel) {
      const siblingLabel = parent.querySelector(':scope > label, :scope > [data-label], :scope > .label, :scope > .form-label');
      if (siblingLabel && !siblingLabel.contains(element)) signals.push(labelTextOf(siblingLabel));
      if (adjacentNodeLooksLikeLabel(parent.previousElementSibling)) signals.push(labelTextOf(parent.previousElementSibling));
    }
    if (adjacentNodeLooksLikeLabel(element.previousElementSibling)) signals.push(labelTextOf(element.previousElementSibling));

    if (adapter.contextSelectors?.length) {
      try {
        const context = element.closest(adapter.contextSelectors.join(','));
        if (context) signals.push(textOf(context).slice(0, 240));
      } catch {
        // A site-specific selector must not block the generic scanner.
      }
    }

    if (name) signals.push(name);
    if (id) signals.push(id);

    return unique(signals).slice(0, 16);
  }

  const adapterRegistry = [
    {
      id: 'university-portal',
      label: '高校报名系统',
      priority: 40,
      matches(hostname) {
        return /(^|\.)edu\.cn$/i.test(hostname) || /(^|\.)(admission|apply|yz|yjs|grad|campus)\./i.test(hostname);
      },
      contextSelectors: ['.el-form-item', '.ant-form-item', '.layui-form-item', '.form-item', '.field-item', '[class*="formItem"]'],
      fieldAliases: {
        name: ['studentName', 'realName', 'student_name', 'candidateName', 'applyName'],
        email: ['studentEmail', 'contactEmail', 'applyEmail', 'emailAddress'],
        phone: ['studentPhone', 'mobilePhone', 'mobileNumber', 'contactPhone'],
        undergraduateSchool: ['undergraduateSchool', 'collegeName', 'bkschool', 'graduationSchool', 'bachelorSchool'],
        major: ['undergraduateMajor', 'bachelorMajor', 'currentMajor', 'major_name'],
        grade: ['currentGrade', 'studentGrade', 'undergraduateGrade'],
        targetMajor: ['applyMajor', 'targetMajorName', 'applicationMajor', 'intendedMajor'],
        targetRegion: ['targetRegion', 'targetCity', 'intendedCity', 'applicationRegion'],
        targetSchool: ['applySchool', 'targetSchool', 'applicationSchool', 'applyUniversity'],
        targetDepartment: ['applyDepartment', 'targetDepartment', 'applicationCollege', 'applyCollege']
      },
      hint: '已启用高校表单组件、字段名称和常见中英文字段别名。'
    },
    {
      id: 'online-form',
      label: '在线表单系统',
      priority: 30,
      matches(hostname) {
        return /(wj\.qq\.com|jinshuju\.net|wenjuan\.com|forms\.office\.com|formstack\.com)$/i.test(hostname);
      },
      contextSelectors: ['[class*="question"]', '[class*="Question"]', '[class*="form-item"]', '[class*="field"]', '.question', '.form-group'],
      fieldAliases: {
        name: ['你的姓名', '同学姓名', '申请人姓名'],
        email: ['你的邮箱', '常用邮箱'],
        phone: ['你的手机号', '常用手机', '联系方式'],
        undergraduateSchool: ['本科学校名称', '本科高校', '学校全称'],
        major: ['你的本科专业', '本科专业名称'],
        grade: ['你的年级', '目前年级'],
        targetMajor: ['想申请的专业', '报名方向', '志愿方向'],
        targetRegion: ['意向城市', '报考城市', '期望地区'],
        targetSchool: ['想申请的学校', '目标学校'],
        targetDepartment: ['想申请的学院', '目标学院']
      },
      hint: '已启用题目文本、占位符、aria-label 和问卷容器识别。'
    },
    {
      id: 'generic-form',
      label: '通用报名表',
      priority: 10,
      matches() {
        return true;
      },
      fieldAliases: {},
      hint: '按可见标签、字段名称、占位符和辅助文本保守匹配。'
    }
  ];

  function chooseAdapter(hostname = location.hostname) {
    return [...adapterRegistry]
      .filter((adapter) => adapter.matches(hostname))
      .sort((left, right) => right.priority - left.priority)[0] || adapterRegistry[adapterRegistry.length - 1];
  }

  function scoreField(fieldId, candidate, adapter) {
    const definition = fieldDefinitions[fieldId];
    const signals = candidate.signals || [];
    const compactSignal = compactText(signals.join(' '));
    if (!definition || !compactSignal) return 0;

    for (const blocked of definition.blocked || []) {
      if (compactSignal.includes(compactText(blocked))) return -1000;
    }

    if (fieldId === 'major' && /(apply|target|intend|application|报考|申请|意向|目标)/i.test(compactSignal)) return -1000;
    if (fieldId === 'targetMajor' && /(undergraduate|bachelor|current|本科|所学|当前)/i.test(compactSignal)) return -1000;
    if (fieldId === 'undergraduateSchool' && /(apply|target|application|报考|申请|目标)/i.test(compactSignal)) return -1000;
    if (fieldId === 'targetSchool' && /(undergraduate|graduation|bachelor|本科|毕业|就读)/i.test(compactSignal)) return -1000;

    const aliases = [...definition.aliases, ...(adapter.fieldAliases?.[fieldId] || [])];
    let score = 0;
    for (const alias of aliases) {
      const compactAlias = compactText(alias);
      if (!compactAlias) continue;
      if (signals.some((signal) => compactText(signal) === compactAlias)) {
        score = Math.max(score, 110);
      } else if (signals.some((signal) => {
        const compact = compactText(signal);
        return compactAlias.length >= 3 && (compact.startsWith(compactAlias) || compact.endsWith(compactAlias));
      })) {
        score = Math.max(score, 94);
      } else if (compactAlias.length >= 3 && compactSignal.includes(compactAlias)) {
        score = Math.max(score, 82);
      } else if (compactSignal.length >= 3 && compactAlias.includes(compactSignal)) {
        score = Math.max(score, 68);
      }
    }

    const htmlType = normalizeText(candidate.htmlType);
    const autocomplete = normalizeText(candidate.autocomplete);
    if (fieldId === 'email') {
      if (htmlType === 'tel') return -1000;
      if (htmlType === 'email' || autocomplete === 'email') score = Math.max(score, 90);
    }
    if (fieldId === 'phone') {
      if (htmlType === 'email') return -1000;
      if (htmlType === 'tel' || autocomplete === 'tel') score = Math.max(score, 90);
    }
    if (fieldId === 'name' && ['name', 'given-name', 'family-name'].includes(autocomplete)) {
      score = Math.max(score, 96);
    }

    return score;
  }

  function summarizeAlternative(item) {
    return {
      score: item.score,
      matchedBy: item.candidate.signals[0] || '表单字段',
      candidateIndex: item.candidate.index
    };
  }

  function buildPublicMatch(fieldId, assignment) {
    const definition = fieldDefinitions[fieldId];
    if (!assignment) {
      return {
        fieldId,
        label: definition.label,
        status: 'not-found',
        confidence: 'none',
        currentValue: ''
      };
    }

    const { candidate, score } = assignment;
    return {
      fieldId,
      label: definition.label,
      status: 'matched',
      confidence: score >= 90 ? 'high' : score >= 78 ? 'medium' : 'low',
      matchScore: score,
      matchedBy: candidate.signals[0] || '表单字段',
      currentValue: String(candidate.element?.value || '').slice(0, 120),
      inputType: String(candidate.element?.tagName || candidate.tagName || '').toLowerCase(),
      candidateIndex: candidate.index,
      element: candidate.element
    };
  }

  function matchFieldCandidates(candidates, adapter) {
    const rankings = new Map();
    const ambiguousFields = new Map();

    for (const fieldId of Object.keys(fieldDefinitions)) {
      const ranked = candidates
        .map((candidate) => ({ candidate, score: scoreField(fieldId, candidate, adapter) }))
        .filter((item) => item.score >= MATCH_THRESHOLD)
        .sort((left, right) => right.score - left.score || left.candidate.index - right.candidate.index);
      rankings.set(fieldId, ranked);
      if (ranked.length > 1 && ranked[0].score - ranked[1].score <= AMBIGUITY_GAP) {
        ambiguousFields.set(fieldId, ranked.slice(0, 3));
      }
    }

    const assignments = new Map();
    const usedCandidates = new Set();
    const edges = [];
    for (const [fieldId, ranked] of rankings) {
      if (ambiguousFields.has(fieldId)) continue;
      for (const item of ranked) edges.push({ fieldId, ...item });
    }
    edges.sort((left, right) => right.score - left.score || left.candidate.index - right.candidate.index);

    for (const edge of edges) {
      if (assignments.has(edge.fieldId) || usedCandidates.has(edge.candidate.index)) continue;
      assignments.set(edge.fieldId, edge);
      usedCandidates.add(edge.candidate.index);
    }

    return Object.keys(fieldDefinitions).map((fieldId) => {
      const ambiguous = ambiguousFields.get(fieldId);
      if (ambiguous) {
        return {
          fieldId,
          label: fieldDefinitions[fieldId].label,
          status: 'ambiguous',
          confidence: 'review',
          currentValue: '',
          alternatives: ambiguous.map(summarizeAlternative)
        };
      }
      return buildPublicMatch(fieldId, assignments.get(fieldId));
    });
  }

  function scanPage() {
    const adapter = chooseAdapter();
    const candidates = [...document.querySelectorAll('input, textarea, select')]
      .filter(elementIsFillable)
      .map((element, index) => ({
        element,
        index,
        tagName: element.tagName,
        htmlType: element.getAttribute('type') || element.tagName.toLowerCase(),
        autocomplete: element.getAttribute('autocomplete') || '',
        signals: getElementSignals(element, adapter)
      }));
    const fields = matchFieldCandidates(candidates, adapter);

    return {
      adapterId: adapter.id,
      adapterLabel: adapter.label,
      adapterHint: adapter.hint,
      hostname: location.hostname,
      pageTitle: document.title,
      candidateCount: candidates.length,
      fields,
      matchedCount: fields.filter((field) => field.status === 'matched').length,
      ambiguousCount: fields.filter((field) => field.status === 'ambiguous').length,
      totalCount: fields.length
    };
  }

  globalThis.SeekOfferFillAdapters = {
    AMBIGUITY_GAP,
    MATCH_THRESHOLD,
    adapterRegistry,
    adjacentNodeLooksLikeLabel,
    chooseAdapter,
    compactText,
    elementLooksSensitive,
    fieldDefinitions,
    getElementSignals,
    matchFieldCandidates,
    normalizeText,
    scanPage,
    scoreField
  };
})();
