(() => {
  if (globalThis.__seekOfferFillPageAgentLoaded) return;
  globalThis.__seekOfferFillPageAgentLoaded = true;

  function publicScan(scan) {
    return {
      ...scan,
      fields: scan.fields.map((field) => Object.fromEntries(Object.entries(field).filter(([key]) => key !== 'element')))
    };
  }

  function scanPage() {
    return globalThis.SeekOfferFillAdapters.scanPage();
  }

  function normalizeChoice(value) {
    return String(value || '')
      .replace(/\s+/g, '')
      .replace(/[：:（）()【】\[\]、,，.。\-_/\\]/g, '')
      .trim()
      .toLowerCase();
  }

  function getElementValue(element) {
    return String(element?.value || '').trim();
  }

  function findSelectOption(element, value) {
    const target = normalizeChoice(value);
    if (!target) return null;
    const options = [...element.options]
      .map((option) => ({
        option,
        text: normalizeChoice(option.textContent),
        value: normalizeChoice(option.value)
      }))
      .filter((item) => item.text || item.value);

    const exact = options.find((item) => item.value === target || item.text === target);
    if (exact) return exact.option;

    const fuzzy = options.filter((item) => {
      if (target.length < 2) return false;
      return (item.text.length >= 2 && (item.text.includes(target) || target.includes(item.text))) ||
        (item.value.length >= 2 && (item.value.includes(target) || target.includes(item.value)));
    });
    return fuzzy.length === 1 ? fuzzy[0].option : null;
  }

  function dispatchValueEvents(element) {
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    element.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  function setNativeValue(element, value) {
    element.focus({ preventScroll: true });
    if (element.tagName === 'SELECT') {
      const option = findSelectOption(element, value);
      if (!option) return { ok: false, reason: 'option-not-found' };
      element.value = option.value;
      dispatchValueEvents(element);
      return { ok: true };
    }

    const prototype = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(prototype, 'value');
    if (descriptor?.set) {
      descriptor.set.call(element, String(value ?? ''));
    } else {
      element.value = String(value ?? '');
    }
    dispatchValueEvents(element);
    return { ok: true };
  }

  function fillFields(fields, overwriteExisting = false) {
    const scan = scanPage();
    const requested = Array.isArray(fields) ? fields.slice(0, 30) : [];
    const results = requested.map((field) => {
      const value = typeof field?.value === 'string' ? field.value.trim() : '';
      if (!value) return { id: field?.id || '', status: 'empty-value', label: field?.label || field?.id || '' };

      const match = scan.fields.find((item) => item.fieldId === field.id && item.status === 'matched' && item.element);
      if (!match) return { id: field.id, status: 'not-found', label: field.label || field.id };
      if (match.element.isConnected === false) return { id: field.id, status: 'stale-field', label: field.label || match.label };

      const currentValue = getElementValue(match.element);
      if (normalizeChoice(currentValue) === normalizeChoice(value)) {
        return { id: field.id, status: 'unchanged', label: field.label || match.label, matchedBy: match.matchedBy };
      }
      if (currentValue && !overwriteExisting) {
        return {
          id: field.id,
          status: 'existing-value',
          label: field.label || match.label,
          matchedBy: match.matchedBy,
          currentValue: currentValue.slice(0, 120)
        };
      }

      const result = setNativeValue(match.element, value);
      return {
        id: field.id,
        status: result.ok ? 'filled' : result.reason || 'skipped',
        label: field.label || match.label,
        matchedBy: match.matchedBy
      };
    });

    return {
      adapterId: scan.adapterId,
      results,
      filledCount: results.filter((item) => item.status === 'filled').length,
      unchangedCount: results.filter((item) => item.status === 'unchanged').length,
      protectedCount: results.filter((item) => item.status === 'existing-value').length,
      skippedCount: results.filter((item) => !['filled', 'unchanged'].includes(item.status)).length
    };
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === 'SCAN_PAGE') {
      sendResponse({ ok: true, protocolVersion: 2, scan: publicScan(scanPage()) });
      return false;
    }

    if (message?.type === 'FILL_FIELDS') {
      sendResponse({
        ok: true,
        protocolVersion: 2,
        result: fillFields(message.fields, message.overwriteExisting === true)
      });
      return false;
    }

    sendResponse({ ok: false, error: 'unsupported_message' });
    return false;
  });

  globalThis.SeekOfferFillPageAgent = {
    fillFields,
    findSelectOption,
    normalizeChoice,
    publicScan
  };
})();
