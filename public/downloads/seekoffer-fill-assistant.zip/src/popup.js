const state = {
  tabId: null,
  tabUrl: '',
  scan: null,
  payload: null,
  payloadKey: '',
  defaultsAppliedForKey: '',
  selectedFieldIds: new Set(),
  overwriteExisting: false
};

const elements = {};

function setStatus(title, detail, tone = 'ready') {
  elements.statusTitle.textContent = title;
  elements.statusDetail.textContent = detail;
  elements.statusDot.className = `status-dot ${tone}`;
}

function sendMessage(message) {
  return chrome.runtime.sendMessage(message);
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0] || null;
}

function isSeekofferUrl(value) {
  try {
    const url = new URL(value);
    return url.hostname === 'seekoffer.com.cn' || url.hostname === 'www.seekoffer.com.cn';
  } catch {
    return false;
  }
}

async function ensurePageAgent() {
  if (!state.tabId) throw new Error('没有找到当前标签页');
  await chrome.scripting.executeScript({
    target: { tabId: state.tabId },
    files: ['src/adapters.js', 'src/page-agent.js']
  });
}

async function sendToPage(message) {
  if (!state.tabId) throw new Error('没有找到当前标签页');
  return chrome.tabs.sendMessage(state.tabId, message);
}

function formatPayloadExpiry(payload) {
  const expiresAt = Date.parse(String(payload?.expiresAt || ''));
  if (!Number.isFinite(expiresAt)) return '';
  const remainingMinutes = Math.max(0, Math.ceil((expiresAt - Date.now()) / 60000));
  return remainingMinutes ? `约 ${remainingMinutes} 分钟后自动清除` : '即将自动清除';
}

async function loadPayload() {
  const response = await sendMessage({ type: 'GET_FILL_PAYLOAD' });
  if (!response?.ok) throw new Error('无法读取寻鹿暂存字段');
  state.payload = response.payload || null;
  const nextPayloadKey = state.payload?.updatedAt || '';
  if (state.payloadKey !== nextPayloadKey) {
    state.payloadKey = nextPayloadKey;
    state.selectedFieldIds.clear();
    state.defaultsAppliedForKey = '';
  }

  const count = state.payload?.fields?.length || 0;
  elements.payloadCount.textContent = String(count);
  if (count) {
    const expiry = formatPayloadExpiry(state.payload);
    elements.payloadDetail.textContent = `已接收 ${count} 个已确认字段${expiry ? `，${expiry}` : ''}。`;
  } else if (response.expired) {
    elements.payloadDetail.textContent = '上一次字段已超过 30 分钟并自动清除，请回寻鹿重新发送。';
  } else {
    elements.payloadDetail.textContent = '请先在寻鹿申请清单中确认并发送字段。';
  }
}

function comparisonValue(value) {
  return String(value || '').replace(/\s+/g, '').trim().toLowerCase();
}

function getFieldMatch(fieldId) {
  return state.scan?.fields?.find((field) => field.fieldId === fieldId) || null;
}

function fieldCanBeSelected(field, match) {
  if (!match || match.status !== 'matched' || match.confidence === 'low') return false;
  const currentValue = String(match.currentValue || '').trim();
  if (currentValue && comparisonValue(currentValue) === comparisonValue(field.value)) return false;
  return !currentValue || state.overwriteExisting;
}

function fieldBadge(field, match) {
  if (!match || match.status === 'not-found') return { text: '未找到', tone: 'missing' };
  if (match.status === 'ambiguous') return { text: '有歧义', tone: 'review' };
  if (match.confidence === 'low') return { text: '请手填', tone: 'review' };
  const currentValue = String(match.currentValue || '').trim();
  if (currentValue && comparisonValue(currentValue) === comparisonValue(field.value)) return { text: '已一致', tone: 'ready' };
  if (currentValue && !state.overwriteExisting) return { text: '已有内容', tone: 'review' };
  return { text: match.confidence === 'high' ? '高置信' : '需核对', tone: match.confidence === 'high' ? 'ready' : 'review' };
}

function renderReviewFields({ applyDefaults = false } = {}) {
  elements.fieldList.replaceChildren();
  const payloadFields = state.payload?.fields || [];
  if (!payloadFields.length) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.textContent = '没有待填字段。回到寻鹿工作台，选择申请项目并发送已确认字段。';
    elements.fieldList.appendChild(empty);
    updateActionState();
    return;
  }

  for (const field of payloadFields) {
    const match = getFieldMatch(field.id);
    const selectable = fieldCanBeSelected(field, match);
    const currentValue = String(match?.currentValue || '').trim();
    if (applyDefaults && selectable && match?.confidence === 'high' && !currentValue) {
      state.selectedFieldIds.add(field.id);
    }
    if (!selectable) state.selectedFieldIds.delete(field.id);

    const row = document.createElement('label');
    row.className = `field-row${selectable ? '' : ' unavailable'}${state.selectedFieldIds.has(field.id) ? ' selected' : ''}`;

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = state.selectedFieldIds.has(field.id);
    checkbox.disabled = !selectable;
    checkbox.setAttribute('aria-label', `选择${field.label}`);
    checkbox.addEventListener('change', () => {
      if (checkbox.checked) state.selectedFieldIds.add(field.id);
      else state.selectedFieldIds.delete(field.id);
      row.classList.toggle('selected', checkbox.checked);
      updateActionState();
    });

    const main = document.createElement('span');
    main.className = 'field-main';
    const title = document.createElement('span');
    title.className = 'field-title';
    const strong = document.createElement('strong');
    strong.textContent = field.label;
    title.appendChild(strong);

    const value = document.createElement('span');
    value.className = 'field-value';
    value.textContent = field.value;

    const matchDetail = document.createElement('span');
    matchDetail.className = 'field-match';
    if (match?.status === 'matched') {
      matchDetail.textContent = currentValue
        ? `页面已有：${currentValue} · 匹配：${match.matchedBy || '表单字段'}`
        : `匹配：${match.matchedBy || '表单字段'} · ${match.confidence === 'high' ? '高置信度' : '请人工核对'}`;
    } else if (match?.status === 'ambiguous') {
      matchDetail.textContent = '页面上存在多个相似字段，为避免误填已停用自动填写。';
    } else {
      matchDetail.textContent = '当前页面没有找到对应字段。';
    }
    main.append(title, value, matchDetail);

    const badgeData = fieldBadge(field, match);
    const badge = document.createElement('span');
    badge.className = `field-badge ${badgeData.tone}`;
    badge.textContent = badgeData.text;

    row.append(checkbox, main, badge);
    elements.fieldList.appendChild(row);
  }
  updateActionState();
}

function updateAdapterSummary() {
  const scan = state.scan;
  elements.adapterName.textContent = scan?.adapterLabel || '未识别';
  elements.adapterHint.textContent = scan?.adapterHint || '打开报名表后点击重新识别。';
  elements.adapterMeta.textContent = scan
    ? `发现 ${scan.candidateCount || 0} 个可填写控件 · 匹配 ${scan.matchedCount || 0} 项${scan.ambiguousCount ? ` · ${scan.ambiguousCount} 项有歧义` : ''}`
    : '尚未读取页面字段';
}

function getSelectedPayload() {
  const payloadFields = state.payload?.fields || [];
  return payloadFields.filter((field) => state.selectedFieldIds.has(field.id) && fieldCanBeSelected(field, getFieldMatch(field.id)));
}

function updateActionState() {
  const selectedCount = getSelectedPayload().length;
  elements.fillButton.disabled = selectedCount === 0;
  elements.fillButton.textContent = selectedCount ? `填入所选 ${selectedCount} 项` : '填入所选字段';
  elements.selectionSummary.textContent = selectedCount ? `已选择 ${selectedCount} 项；填入后仍需你逐项核对并手动提交` : '尚未选择可填字段';
}

async function scanCurrentPage({ keepStatus = false } = {}) {
  try {
    if (!keepStatus) setStatus('正在识别当前页面', '读取可见报名字段，不读取密码、验证码和提交按钮。', 'pending');
    await ensurePageAgent();
    const [scanResponse] = await Promise.all([sendToPage({ type: 'SCAN_PAGE' }), loadPayload()]);
    if (!scanResponse?.ok) throw new Error(scanResponse?.error || '识别失败');
    state.scan = scanResponse.scan;
    updateAdapterSummary();
    const shouldApplyDefaults = Boolean(state.payloadKey && state.defaultsAppliedForKey !== state.payloadKey);
    renderReviewFields({ applyDefaults: shouldApplyDefaults });
    if (shouldApplyDefaults) state.defaultsAppliedForKey = state.payloadKey;

    if (!keepStatus) {
      const selectedCount = getSelectedPayload().length;
      if (!state.payload?.fields?.length) {
        setStatus('页面已识别，等待寻鹿字段', '回到寻鹿工作台发送字段后，再打开此插件。', 'warning');
      } else if (selectedCount) {
        setStatus('字段已匹配', `已默认选择 ${selectedCount} 个高置信且为空的字段，请核对后填入。`, 'ready');
      } else {
        setStatus('需要人工核对', '没有可安全默认选择的字段，请检查已有内容或匹配状态。', 'warning');
      }
    }
  } catch (error) {
    state.scan = null;
    updateAdapterSummary();
    renderReviewFields();
    setStatus('无法识别当前页面', error?.message || '请确认当前是普通网页，并重试。', 'error');
    elements.adapterMeta.textContent = 'Chrome/Edge 内置页、扩展商店页和受限页面不支持注入。';
  }
}

async function fillCurrentPage() {
  const fields = getSelectedPayload();
  if (!fields.length) return;

  try {
    elements.fillButton.disabled = true;
    setStatus('正在填入所选字段', '不会点击保存、下一步或提交按钮。', 'pending');
    const response = await sendToPage({
      type: 'FILL_FIELDS',
      fields,
      overwriteExisting: state.overwriteExisting
    });
    if (!response?.ok) throw new Error(response?.error || '填入失败');
    const result = response.result;

    const scanResponse = await sendToPage({ type: 'SCAN_PAGE' });
    if (scanResponse?.ok) {
      state.scan = scanResponse.scan;
      state.selectedFieldIds.clear();
      updateAdapterSummary();
      renderReviewFields();
    }

    const detailParts = [`成功填入 ${result.filledCount} 项`];
    if (result.unchangedCount) detailParts.push(`${result.unchangedCount} 项原本一致`);
    if (result.protectedCount) detailParts.push(`${result.protectedCount} 项因已有内容受到保护`);
    if (result.skippedCount - result.protectedCount > 0) detailParts.push(`${result.skippedCount - result.protectedCount} 项未填入`);
    setStatus('本次填入完成', `${detailParts.join('，')}。请在提交前逐项核对。`, result.filledCount ? 'ready' : 'warning');
  } catch (error) {
    setStatus('填入失败', error?.message || '请重新识别当前页面后再试。', 'error');
    updateActionState();
  }
}

async function clearPayload() {
  const response = await sendMessage({ type: 'CLEAR_FILL_PAYLOAD' });
  if (!response?.ok) {
    setStatus('清空失败', '请关闭并重新打开插件后再试。', 'error');
    return;
  }
  state.payload = null;
  state.payloadKey = '';
  state.defaultsAppliedForKey = '';
  state.selectedFieldIds.clear();
  elements.payloadCount.textContent = '0';
  elements.payloadDetail.textContent = '已清空本次暂存字段。';
  renderReviewFields();
  setStatus('暂存字段已清空', '报名页面中的现有内容不会被删除。', 'ready');
}

async function initializePopup() {
  const versionBadge = document.querySelector('#version-badge');
  if (versionBadge) versionBadge.textContent = `v${chrome.runtime.getManifest().version}`;
  elements.statusDot = document.querySelector('#status-dot');
  elements.statusTitle = document.querySelector('#status-title');
  elements.statusDetail = document.querySelector('#status-detail');
  elements.adapterName = document.querySelector('#adapter-name');
  elements.adapterHint = document.querySelector('#adapter-hint');
  elements.adapterMeta = document.querySelector('#adapter-meta');
  elements.fieldList = document.querySelector('#field-list');
  elements.payloadCount = document.querySelector('#payload-count');
  elements.payloadDetail = document.querySelector('#payload-detail');
  elements.selectionSummary = document.querySelector('#selection-summary');
  elements.overwriteToggle = document.querySelector('#overwrite-toggle');
  elements.rescanButton = document.querySelector('#rescan-button');
  elements.fillButton = document.querySelector('#fill-button');
  elements.clearButton = document.querySelector('#clear-button');

  elements.rescanButton.addEventListener('click', () => scanCurrentPage());
  elements.fillButton.addEventListener('click', fillCurrentPage);
  elements.clearButton.addEventListener('click', clearPayload);
  elements.overwriteToggle.addEventListener('change', () => {
    state.overwriteExisting = elements.overwriteToggle.checked;
    renderReviewFields();
  });

  const tab = await getActiveTab();
  state.tabId = tab?.id ?? null;
  state.tabUrl = tab?.url || '';
  if (!state.tabId) {
    setStatus('没有找到当前页面', '请切换到报名页面后重试。', 'error');
    return;
  }

  if (isSeekofferUrl(state.tabUrl)) {
    await loadPayload();
    updateAdapterSummary();
    renderReviewFields();
    setStatus('字段已在寻鹿准备', '请切换到学校报名页面，再点击插件图标进行识别和填入。', 'warning');
    return;
  }

  await scanCurrentPage();
}

document.addEventListener('DOMContentLoaded', () => {
  void initializePopup();
});
