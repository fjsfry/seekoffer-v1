# Chrome Web Store / Edge Add-ons 上架文案

## 基本信息

- 版本：1.0.0
- 名称：寻鹿填报助手
- 简短说明：在保研报名页识别表单，将你在寻鹿确认的资料逐项安全填入；不读取验证码，不自动提交。
- 类别：生产力工具
- 语言：简体中文
- 官网：<https://www.seekoffer.com.cn/me/>
- 隐私政策：<https://www.seekoffer.com.cn/privacy/>
- 支持邮箱：`seekoffer@qq.com`

## 单一用途声明

接收用户在寻鹿 SeekOffer 主动确认的保研报名字段，在用户当前打开的报名网页中识别对应表单，并让用户逐项选择后填入。

## 详细介绍

保研报名信息高度重复，但各校报名系统字段名称和页面结构并不一致。寻鹿填报助手把“资料准备”和“网页填入”分成两个明确步骤：

1. 在寻鹿工作台选择目标申请，补充并逐项确认本次要使用的字段；
2. 打开学校报名页并点击插件，查看识别结果、页面原有内容和匹配置信度；
3. 只勾选你确认无误的字段后填入，最后仍由你逐项核对并手动提交。

安全边界：

- 不读取密码、验证码、文件上传或身份证号；
- 不点击保存、下一步或提交；
- 默认只填空字段，已有内容受到保护；
- 相似字段存在歧义时停止自动填入；
- 字段只在扩展会话保存 30 分钟，可随时清空；
- 报名字段不会上传到计费接口，也不会用于广告。

免费账号每月可发送 3 组字段；SeekOffer Pro 可不限次数使用，并解锁无限申请项目。页面识别、字段预览和失败重试不会消耗次数。

插件可免费安装，购买和权益管理仅在寻鹿官网完成，扩展内不直接收款。

## 权限理由（开发者后台）

- `activeTab`：用户点击插件图标后，临时读取当前报名页的可见表单结构。
- `alarms`：在字段暂存满 30 分钟时触发本地清理，不发送通知。
- `scripting`：向当前标签页注入插件包内的表单识别和填入脚本；不加载远程代码。
- `storage`：在扩展会话中暂存用户确认的字段，最长 30 分钟。
- `seekoffer.com.cn` / `www.seekoffer.com.cn`：与寻鹿工作台建立页面桥接，接收用户主动发送的字段。
- `mnotoltpythkayguhnrk.supabase.co`：通过 HTTPS 兑换一次性随机授权，仅传令牌，不传报名字段或浏览记录。

## 隐私实践后台勾选建议

如实申报插件处理以下类型：个人身份信息、表单数据、网站内容。用途仅选择“应用功能”和必要的“安全/防滥用”。不得勾选广告、个性化或出售数据。提交前逐项核对后台申报与 `PRIVACY.md`、网站隐私政策及实际网络请求完全一致。

## 上架图片

- 扩展图标：`icons/icon-128.png`（ZIP 内必需）。
- 小型宣传图：`public/extension-store/promo-small-440x280.png`。
- 大型宣传图：`public/extension-store/promo-marquee-1400x560.png`。
- 截图 1：`public/extension-store/screenshot-01-safe-match-1280x800.png`。
- 截图 2：`public/extension-store/screenshot-02-review-boundary-1280x800.png`。
- 截图 3：`public/extension-store/screenshot-03-confirmed-flow-1280x800.png`。

## 发布前人工步骤

1. 在 Chrome Web Store 开发者账号创建条目并上传 `public/downloads/seekoffer-fill-assistant.zip`。
2. 上传宣传图和截图，粘贴本文件文案。
3. 填写隐私实践、单一用途、权限理由和支持联系方式。
4. 先发布至可信测试者，使用正式商店安装包完成一次寻鹿登录、授权、识别、填入和清空测试。
5. 测试通过后提交公开审核；Edge Add-ons 使用同一 ZIP 和等价披露。
